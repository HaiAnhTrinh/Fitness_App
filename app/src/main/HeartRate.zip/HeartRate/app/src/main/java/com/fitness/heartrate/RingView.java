package com.fitness.heartrate;

public class RingView {
}
